#!/bin/bash
# Version 1.0
# Prepare deploy

sudo apt install python-pip
sudo pip install ansible 

